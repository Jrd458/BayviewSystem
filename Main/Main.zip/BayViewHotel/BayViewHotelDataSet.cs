﻿namespace BayViewHotel
{


    partial class BayViewHotelDataSet
    {
    }
}

namespace BayViewHotel.BayViewHotelDataSetTableAdapters {
    
    
    public partial class CustomerBookingTableAdapter {
    }
}
